# empty-node-project
Empty stub so I can quickly initialie node cli projects by CURLing this. Test toast plz ignore
